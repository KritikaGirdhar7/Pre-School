/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conn;

/**
 *
 * @author Sandy
 */
public class Answer {
 private String answer;
 private boolean correct;
   
 public Answer(String answer,boolean correct){
    
    this.answer=answer;
    this.correct=correct;
    }
 
 public String getAnswer(){
 return answer;
 }
 
 public void setAnswer(String answer){
  this.answer=answer;
 
 }
 
 
 public boolean isCorrect(){
 
 return correct;
 }
 
 public void setCorrect(boolean correct){
 this.correct=correct;
 
 }
 
 
 public String toString(char letter){
 
 return letter+":"+answer;
 }
    
    
    
    
}
